import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'dart:convert';
import 'utilisateur.dart';

class LivreDetail extends StatefulWidget {
  final Map<String, dynamic> livre;

  LivreDetail({required this.livre});

  @override
  _LivreDetailState createState() => _LivreDetailState();
}

class _LivreDetailState extends State<LivreDetail> {
  List<Map<String, dynamic>> _commentaires = [];
  Set<int> _clickedIndices = Set();
  bool _isAddedToRecommandations = false;
  bool _isAddedToBibli = false;
  final TextEditingController _commentController = TextEditingController();
  double _newCommentRating = 0;

  @override
  void initState() {
    super.initState();
    _loadCommentaires();
  }

  Future<void> _loadCommentaires() async {
    try {
      final String response = await rootBundle.loadString('data/commentaire.json');
      final List<dynamic> data = json.decode(response);
      setState(() {
        _commentaires = data.map((item) => {
          'user': item['user'],
          'rating': item['rating'],
          'comment': item['comment'],
          'utile': item['utile'] ?? 0,
        }).toList();
      });
    } catch (e) {
      print('Error loading commentaires: $e');
    }
  }


  void _incrementUtile(int index) {
    if (!_clickedIndices.contains(index)) {
      setState(() {
        _commentaires[index]['utile'] += 1;
        _clickedIndices.add(index);
      });
    }
  }

  void _addComment() {
    if (_commentController.text.isNotEmpty) {
      setState(() {
        _commentaires.add({
          'user': 'Moi', // Replace with actual user data
          'rating': widget.livre['rating'].toInt(),
          'comment': _commentController.text,
          'utile': 0,
        });
        _commentController.clear();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.livre['title'])),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Image.asset(
                widget.livre['image'],
                width: 200,
                height: 300,
                fit: BoxFit.contain,
              ),
            ),
            SizedBox(height: 16),
            Text(widget.livre['title'], style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('Auteur : ${widget.livre['autor']}'),
            Row(
              children: List.generate(
                5,
                (index) => Icon(
                  index < widget.livre['rating'].toInt()
                      ? Icons.star
                      : Icons.star_border,
                  color: Colors.amber,
                ),
              ),
            ),
            SizedBox(height: 16),
            Text(widget.livre['summary'], style: TextStyle(fontSize: 16)),
            SizedBox(height: 16),
            
            TextButton(
              onPressed: () {
                setState(() {
                  _isAddedToBibli = !_isAddedToBibli;
                });
              },
              child: Text(_isAddedToBibli ? 'Retirer de ma bibliothéque' : 'Ajouter à ma bibliothéque'),
            ),
            TextButton(
              onPressed: () {
                setState(() {
                  _isAddedToRecommandations = !_isAddedToRecommandations;
                });
              },
              child: Text(_isAddedToRecommandations ? 'Retirer de mes recommandations' : 'Ajouter à mes recommandations'),
            ),
            SizedBox(height: 16),
            TextField(
              controller: _commentController,
              decoration: InputDecoration(
                labelText: 'Ajouter un commentaire',
                border: OutlineInputBorder(),
              ),
            ),
            ElevatedButton(
              onPressed: _addComment,
              child: Text('Ajouter le commentaire'),
            ),
            SizedBox(height: 16),
            Text('Commentaires', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: _commentaires.length,
              itemBuilder: (context, index) {
                return Card(
                  margin: EdgeInsets.symmetric(vertical: 8.0),
                  child: ListTile(
                    title: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => Utilisateur(user: _commentaires[index]['user']),
                          ),
                        );
                      },
                      child: Text(_commentaires[index]['user'], style: TextStyle(color: Colors.blue)),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: List.generate(
                            5,
                            (starIndex) => Icon(
                              starIndex < _commentaires[index]['rating']
                                  ? Icons.star
                                  : Icons.star_border,
                              color: Colors.amber,
                            ),
                          ),
                        ),
                        Text(_commentaires[index]['comment']),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text('Utile: ${_commentaires[index]['utile']}'),
                            IconButton(
                              icon: Icon(Icons.thumb_up),
                              onPressed: () => _incrementUtile(index),
                              color: _clickedIndices.contains(index) ? Colors.blue : Colors.grey,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
