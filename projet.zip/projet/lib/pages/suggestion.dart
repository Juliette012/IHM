import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import 'livre.dart';
import 'bibliotheque.dart';

class Suggestion extends StatefulWidget {
  @override
  _SuggestionState createState() => _SuggestionState();
}

class _SuggestionState extends State<Suggestion> {
  List<Map<String, dynamic>> _suggestions = [];

  @override
  void initState() {
    super.initState();
    _loadSuggestions();
  }

  Future<void> _loadSuggestions() async {
    final String response = await rootBundle.loadString('assets/data/livres.json');
    final List<dynamic> data = json.decode(response);
    setState(() {
      _suggestions = data.take(6).map((item) => {
        'title': item['titre'],
        'autor': item['auteur'],
        'rating': item['note'],
        'summary': item['resume'],
        'image': item['image'],
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MenuWidget(),
      body: ListView.builder(
        itemCount: _suggestions.length,
        itemBuilder: (context, index) {
          return Livre(livre: _suggestions[index]);
        },
      ),
    );
  }
}
