import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;

class Utilisateur extends StatefulWidget {
  final String user;

  Utilisateur({required this.user});

  @override
  _UtilisateurState createState() => _UtilisateurState();
}

class _UtilisateurState extends State<Utilisateur> {
  List<Map<String, dynamic>> _recommandation = [];
  Set<int> _likedIndices = Set();

  @override
  void initState() {
    super.initState();
    _loadRecommandation();
  }

  Future<void> _loadRecommandation() async {
    final String response = await rootBundle.loadString('data/recoUtilisateur.json');
    final List<dynamic> data = json.decode(response);
    setState(() {
      _recommandation = data.map((item) => {
        'title': item['titre'],
        'autor': item['auteur'],
        'rating': item['note'],
        'summary': item['resume'],
        'image': item['image'],
        'reco': item['reco']
      }).toList();
    });
  }

  void _toggleLikeRecommendation(int index) {
    setState(() {
      if (_likedIndices.contains(index)) {
        _likedIndices.remove(index);
      } else {
        _likedIndices.add(index);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Recommandation de ${widget.user}')),
      body: _recommandation.isEmpty
          ? Center(child: Text('Aucune recommandation trouvée pour cet utilisateur.'))
          : ListView.builder(
              padding: const EdgeInsets.all(16.0),
              itemCount: _recommandation.length,
              itemBuilder: (context, index) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_recommandation[index]['title'], style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                    SizedBox(height: 8),
                    Text('Auteur : ${_recommandation[index]['autor']}'),
                    SizedBox(height: 8),
                    Text(_recommandation[index]['summary']),
                    SizedBox(height: 8),
                    Image.asset(_recommandation[index]['image']),
                    SizedBox(height: 8),
                    Text('Recommandation : ${_recommandation[index]['reco']}'),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        IconButton(
                          icon: Icon(
                            _likedIndices.contains(index) ? Icons.thumb_up : Icons.thumb_up_off_alt,
                            color: _likedIndices.contains(index) ? Colors.blue : Colors.grey,
                          ),
                          onPressed: () => _toggleLikeRecommendation(index),
                        ),
                      ],
                    ),
                    Divider(),
                  ],
                );
              },
            ),
    );
  }
}