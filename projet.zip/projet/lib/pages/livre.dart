import 'package:flutter/material.dart';
import 'livre_detail.dart';

class Livre extends StatelessWidget {
  final Map<String, dynamic> livre;

  Livre({required this.livre});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => LivreDetail(livre: livre)),
        );
      },
      child: Card(
        margin: EdgeInsets.all(8.0),
        child: Row(
          children: [
            Image.asset(livre['image'], width: 100, height: 150, fit: BoxFit.cover),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      livre['title'],
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    Text('Auteur : ${livre['autor']}'),
                    Row(
                      children: List.generate(
                        5,
                        (index) => Icon(
                          index < livre['rating'].toInt()
                              ? Icons.star
                              : Icons.star_border,
                          color: Colors.amber,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
