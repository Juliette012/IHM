import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'livre.dart';
import 'suggestion.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'dart:convert';
import 'recommandation.dart';

class Bibliotheque extends StatefulWidget {
  @override
  _BibliothequeState createState() => _BibliothequeState();
}

class _BibliothequeState extends State<Bibliotheque> {
  List<Map<String, dynamic>> _livres = [];
  String _sortCriteria = 'title';

  @override
  void initState() {
    super.initState();
    _loadLivres();
  }

  Future<void> _loadLivres() async {
    try {
      final String response = await rootBundle.loadString('assets/data/meslivres.json');
      final List<dynamic> data = json.decode(response);
      setState(() {
        _livres = data.map((item) => {
          'title': item['titre'],
          'autor': item['auteur'],
          'rating': item['note'],
          'summary': item['resume'],
          'image': item['image'],
        }).toList();
        _sortLivres();
      });
    } catch (e) {
      print('Error loading livres: $e');
    }
  }

  void _sortLivres() {
    setState(() {
      _livres.sort((a, b) {
        if (_sortCriteria == 'title') {
          return a['title'].compareTo(b['title']);
        } else if (_sortCriteria == 'autor') {
          return a['autor'].compareTo(b['autor']);
        } else if (_sortCriteria == 'rating') {
          return b['rating'].compareTo(a['rating']);
        }
        return 0;
      });
    });
  }

  void _changeSortCriteria(String criteria) {
    setState(() {
      _sortCriteria = criteria;
      _sortLivres();
    });
  }

  void _ajouterLivre() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        String title = '';
        String autor = '';
        double rating = 3.0;
        String summary = '';

        return AlertDialog(
          title: Text('Ajouter un livre'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextField(
                onChanged: (value) => title = value,
                decoration: InputDecoration(hintText: "Titre"),
              ),
              TextField(
                onChanged: (value) => autor = value,
                decoration: InputDecoration(hintText: "Auteur"),
              ),
              RatingBar.builder(
                initialRating: rating,
                minRating: 1,
                direction: Axis.horizontal,
                allowHalfRating: true,
                itemCount: 5,
                itemBuilder: (context, _) => Icon(Icons.star, color: Colors.amber),
                onRatingUpdate: (value) => rating = value,
              ),
              TextField(
                onChanged: (value) => summary = value,
                decoration: InputDecoration(hintText: "Résumé"),
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Annuler'),
              onPressed: () => Navigator.of(context).pop(),
            ),
            TextButton(
              child: Text('Ajouter'),
              onPressed: () {
                if (title.isNotEmpty && autor.isNotEmpty) {
                  setState(() {
                    _livres.add({
                      'title': title,
                      'autor': autor,
                      'rating': rating,
                      'summary': summary,
                      'image': 'https://via.placeholder.com/100',
                    });
                    _sortLivres();
                  });
                  Navigator.of(context).pop();
                }
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MenuWidget(),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 25.0, vertical: 6.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 18.0, vertical: 6.0),
                  decoration: BoxDecoration(
                    color: Color.fromARGB(255, 247, 242, 226),
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                  child: DropdownButton<String>(
                    value: _sortCriteria,
                    dropdownColor: Color.fromARGB(255, 247, 242, 226),
                    style: TextStyle(color: Color.fromARGB(255, 188, 179, 129), fontSize: 16, fontWeight: FontWeight.bold),
                    items: [
                      DropdownMenuItem(value: 'title', child: Text('Titre')),
                      DropdownMenuItem(value: 'autor', child: Text('Auteur')),
                      DropdownMenuItem(value: 'rating', child: Text('Note')),
                    ],
                    onChanged: (value) {
                      if (value != null) {
                        _changeSortCriteria(value);
                      }
                    },
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _livres.length,
              itemBuilder: (context, index) {
                return Livre(livre: _livres[index]);
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _ajouterLivre,
        backgroundColor: Color.fromARGB(255, 237, 229, 201),
        child: Icon(Icons.add, color: Color.fromARGB(255, 188, 179, 129)),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }
}

class MenuWidget extends StatelessWidget implements PreferredSizeWidget {
  @override
  Widget build(BuildContext context) {
    return AppBar(
      automaticallyImplyLeading: false, // Remove the back arrow
      title: Row(
        children: [
          TextButton(
            onPressed: () {
              Navigator.pushReplacement(
                context,
                PageRouteBuilder(
                  pageBuilder: (context, animation1, animation2) => Bibliotheque(),
                  transitionDuration: Duration.zero,
                  reverseTransitionDuration: Duration.zero,
                ),
              );
            },
            child: Text(
              'Bibliothèque',
              style: TextStyle(color: const Color.fromARGB(255, 188, 179, 129), fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pushReplacement(
                context,
                PageRouteBuilder(
                  pageBuilder: (context, animation1, animation2) => Suggestion(),
                  transitionDuration: Duration.zero,
                  reverseTransitionDuration: Duration.zero,
                ),
              );
            },
            child: Text(
              'Suggestions',
              style: TextStyle(color: const Color.fromARGB(255, 188, 179, 129), fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pushReplacement(
                context,
                PageRouteBuilder(
                  pageBuilder: (context, animation1, animation2) => Recommandation(),
                  transitionDuration: Duration.zero,
                  reverseTransitionDuration: Duration.zero,
                ),
              );
            },
            child: Text(
              'Recommandations',
              style: TextStyle(color: const Color.fromARGB(255, 188, 179, 129), fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(kToolbarHeight);
}