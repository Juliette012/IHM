import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import 'livre.dart';
import 'bibliotheque.dart';

class Recommandation extends StatefulWidget {
  @override
  _RecommandationState createState() => _RecommandationState();
}

class _RecommandationState extends State<Recommandation> {
  List<Map<String, dynamic>> _recommandations = [];
  List<TextEditingController> _controllers = [];

  @override
  void initState() {
    super.initState();
    _loadRecommandations();
  }

  Future<void> _loadRecommandations() async {
    final String response = await rootBundle.loadString('assets/data/livres.json');
    final List<dynamic> data = json.decode(response);
    setState(() {
      _recommandations = data.take(2).map((item) => {
        'title': item['titre'],
        'autor': item['auteur'],
        'rating': item['note'],
        'summary': item['resume'],
        'image': item['image'],
        'recommendation': 'Je recommande ce livre parce que...'
      }).toList();
      _controllers = List.generate(_recommandations.length, (index) => TextEditingController(text: _recommandations[index]['recommendation']));
    });
  }

  @override
  void dispose() {
    for (var controller in _controllers) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MenuWidget(),
      body: ListView.builder(
        itemCount: _recommandations.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.all(16.0),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Image.asset(_recommandations[index]['image'], width: 100, height: 150, fit: BoxFit.cover),
                      SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _recommandations[index]['title'],
                              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                            ),
                            Text('Auteur : ${_recommandations[index]['autor']}'),
                            Row(
                              children: List.generate(
                                5,
                                (starIndex) => Icon(
                                  starIndex < _recommandations[index]['rating'].toInt()
                                      ? Icons.star
                                      : Icons.star_border,
                                  color: Colors.amber,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 16),
                  TextField(
                    controller: _controllers[index],
                    maxLines: 3,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Pourquoi recommandez-vous ce livre ?',
                    ),
                    onChanged: (value) {
                      setState(() {
                        _recommandations[index]['recommendation'] = value;
                      });
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
