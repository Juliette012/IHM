import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ma Bibliothèque',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: MyBooksPage(),
    );
  }
}

class MyDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: BoxDecoration(color: Colors.blue),
            child: Text('Menu', style: TextStyle(color: Colors.white, fontSize: 24)),
          ),
          ListTile(
            leading: Icon(Icons.book),
            title: Text('Mes Livres'),
            onTap: () {
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => MyBooksPage()));
            },
          ),
          ListTile(
            leading: Icon(Icons.lightbulb),
            title: Text('Suggestions'),
            onTap: () {
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => SuggestionsPage()));
            },
          ),
        ],
      ),
    );
  }
}

class MyBooksPage extends StatefulWidget {
  @override
  _MyBooksPageState createState() => _MyBooksPageState();
}

class _MyBooksPageState extends State<MyBooksPage> {
  List<Map<String, dynamic>> _books = [];

  final TextEditingController _controller = TextEditingController();

  void _addBook(String title) {
    if (title.isNotEmpty) {
      setState(() {
        _books.add({
          'title': title,
          'height': '${150 + _books.length * 10} cm',
          'rating': 4.0,
          'summary': 'Ceci est un résumé pour le livre "$title".',
          'image': 'https://via.placeholder.com/100', // Image de placeholder
        });
      });
      _controller.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Mes Livres')),
      drawer: MyDrawer(),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _controller,
              decoration: InputDecoration(
                labelText: 'Ajouter un livre',
                suffixIcon: IconButton(
                  icon: Icon(Icons.add),
                  onPressed: () => _addBook(_controller.text),
                ),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _books.length,
              itemBuilder: (context, index) {
                return BookCard(book: _books[index]);
              },
            ),
          ),
        ],
      ),
    );
  }
}

class SuggestionsPage extends StatelessWidget {
  final List<Map<String, dynamic>> _suggestions = [
    {
      'title': 'Le Seigneur des Anneaux',
      'height': '180 cm',
      'rating': 5.0,
      'summary': 'Une épopée fantastique à travers la Terre du Milieu.',
      'image': 'https://via.placeholder.com/100',
    },
    {
      'title': '1984',
      'height': '200 cm',
      'rating': 4.5,
      'summary': 'Un récit dystopique sur un futur totalitaire.',
      'image': 'https://via.placeholder.com/100',
    },
    {
      'title': 'Harry Potter',
      'height': '250 cm',
      'rating': 4.8,
      'summary': 'Les aventures d’un jeune sorcier à Poudlard.',
      'image': 'https://via.placeholder.com/100',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Suggestions de Livres')),
      drawer: MyDrawer(),
      body: ListView.builder(
        itemCount: _suggestions.length,
        itemBuilder: (context, index) {
          return BookCard(book: _suggestions[index]);
        },
      ),
    );
  }
}

// Widget réutilisable pour afficher les livres sous forme de carte
class BookCard extends StatelessWidget {
  final Map<String, dynamic> book;

  BookCard({required this.book});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => BookDetailsPage(book: book)),
        );
      },
      child: Card(
        margin: EdgeInsets.all(8.0),
        child: Row(
          children: [
            Image.network(book['image'], width: 100, height: 150, fit: BoxFit.cover),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      book['title'],
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    Text('Hauteur : ${book['height']}'),
                    SizedBox(height: 8),
                    Row(
                      children: List.generate(
                        5,
                        (starIndex) => Icon(
                          starIndex < book['rating'].toInt() ? Icons.star : Icons.star_border,
                          color: Colors.amber,
                        ),
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      book['summary'],
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Page de détails du livre
class BookDetailsPage extends StatelessWidget {
  final Map<String, dynamic> book;

  BookDetailsPage({required this.book});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(book['title'])),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(book['image'], width: double.infinity, height: 250, fit: BoxFit.cover),
            SizedBox(height: 16),
            Text(book['title'], style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('Hauteur : ${book['height']}'),
            SizedBox(height: 8),
            Row(
              children: List.generate(
                5,
                (starIndex) => Icon(
                  starIndex < book['rating'].toInt() ? Icons.star : Icons.star_border,
                  color: Colors.amber,
                ),
              ),
            ),
            SizedBox(height: 16),
            Text(
              book['summary'],
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}